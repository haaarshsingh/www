I've created some banners and included my headshot in here for easy use and download by conference and event organisers. You can also find my bio amongst other things at hxrsh.in/abt.

For my headshot/picture, I'd prefer you use the original one (as it's in higher quality) and crop it to your likings. If for whatever reason though you're unable to crop it, feel free to use the cropped picture provided.

If you're looking to use a banner, I would prefer you use either the light or the dark one depending upno what stays consistent with your colour scheme.

Questions? Don't hesitate to email me at hi.harsh@pm.me

